const fruits = ["Jeruk", "Apel", "Durian"];

module.exports = fruits;
